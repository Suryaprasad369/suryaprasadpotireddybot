# Import the required libraries
from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse

# Create the Flask app
app = Flask(__name__)

# Define your chatbot responses
def get_response(message):
    # Customize the responses based on the incoming message
    if message.lower() == "hello":
        return "Hi there! How can I assist you?"
    elif message.lower() == "help":
        return "Sure, I'm here to help. What do you need assistance with?"
    else:
        return "I'm sorry, I didn't understand that. Please try again."

# Handle incoming messages
@app.route("/whatsapp", methods=["POST"])
def whatsapp_reply():
    # Get the incoming message content
    incoming_message = request.values.get("Body", "").strip()

    # Generate the chatbot response
    response_message = get_response(incoming_message)

    # Create the TwiML response
    twiml_response = MessagingResponse()
    twiml_response.message(response_message)

    return str(twiml_response)

# Run the Flask app
if __name__ == "__main__":
    app.run(debug=True)